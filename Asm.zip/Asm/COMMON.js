const uri = 'mongodb+srv://Asm:p4xQ1l33JgNUnR7p@cluster0.xopjfar.mongodb.net/asm_api';
module.exports = {
    uri: uri,
}